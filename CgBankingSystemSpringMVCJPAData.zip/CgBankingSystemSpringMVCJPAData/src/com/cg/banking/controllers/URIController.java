package com.cg.banking.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;

@Controller
public class URIController {
Account account;

@RequestMapping("/")
public String getIndexPage() {
	return "indexPage";
}
@RequestMapping("/loginPage")
public String getLoginPage() {
	return "loginPage";
}
@RequestMapping("/headerPage")
public String getHeaderPage() {
	return "headerPage";
}
@RequestMapping("/WelcomePage")
public String getWelcomePage() {
	return "welcomePage";
}
@RequestMapping("/accountOpeningPage")
public String getAccountOpeningPage() {
	return "accountOpeningPage";
}
@RequestMapping("/depositToAccountPage")
public String getDepositToAccountPage() {
	return "depositToAccountPage";
}
@RequestMapping("/withdrawFromAccountPage")
public String getWithdrawFromAccountPage() {
	return "withdrawFromAccountPage";
}
@RequestMapping("/fundsTransferPage")
public String getFundsTransferPage() {
	return "fundsTransferPage";
}
@RequestMapping("/SingleAccountDetails")
public String getSingleAccountDetails() {
	return "getSingleAccountDetails";
}
@RequestMapping("/customerCarePage")
public String getcustomerCarePage() {
	return "customerCarePage";
}
@ModelAttribute
public Account getAccount() {
	account=new Account();
	return account;
}

}
