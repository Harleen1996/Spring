package com.cg.banking.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;


@Controller
public class AccountController {

	@Autowired
	private BankingServices bankingServices;
	
	@RequestMapping("/login")
	public ModelAndView loginAction(@ModelAttribute Account account,HttpServletRequest request) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException {
		HttpSession session=request.getSession();
		session.setAttribute("accountNo", account.getAccountNo());
		return new ModelAndView("welcomePage","account", account);
	}

	@RequestMapping("/openAccount")
	public ModelAndView registerAccountAction(@ModelAttribute Account account) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException {
		
		
		/*if(result.hasErrors())
			return new ModelAndView("accountOpeningPage");*/
		account=bankingServices.openAccount(account);
		return new ModelAndView("accountOpeningSuccessfulPage","account", account);
	}
	
	
	@RequestMapping("/DepositToAccount")
	public ModelAndView depositToAccount(@ModelAttribute Account account,HttpServletRequest request) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		HttpSession session = request.getSession(false);
		int accountNo=(Integer) session.getAttribute("accountNo");
		account.setAccountNo(accountNo);
		account=bankingServices.depositAmount(account);
		return new ModelAndView("welcomePage","account", account);
	}
}
