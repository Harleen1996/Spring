package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHubLoginStepDefinition {
	
	private WebDriver driver;
	private LoginPage loginPage;
	
	@Given("^User is on Github LoginPage$")
	public void user_is_on_Github_LoginPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		
		loginPage=PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^User enter correct username and password$")
	public void user_enter_correct_username_and_password() throws Throwable {
		/*By by=By.name("login");
		WebElement searchTxt=driver.findElement(by);
		searchTxt.sendKeys("harleen1996");
		by=By.name("password");
		searchTxt=driver.findElement(by);
		searchTxt.sendKeys("viveksingla123");
		searchTxt.submit();*/
		
		loginPage.setUsername("Harleen1996");
		loginPage.setPassword("viveksingla123");
		loginPage.clickSignIn();
	}

	@Then("^User should be logged in$")
	public void user_should_be_logged_in() throws Throwable {
		/*String actualTitle=driver.getTitle();
		String expectedTitle="GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();*/
		
		String actualMessage=loginPage.getActualLoginMessage();
		String expectedMessage="https://github.com/Harleen1996";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}
	
	@When("^User enter correct username and wrong password$")
	public void user_enter_correct_username_and_wrong_password() throws Throwable {
		/*By by=By.name("login");
		WebElement searchTxt=driver.findElement(by);
		searchTxt.sendKeys("harleen1996");
		by=By.name("password");
		searchTxt=driver.findElement(by);
		searchTxt.sendKeys("viveksingla");
		searchTxt.submit();*/
		loginPage.setUsername("Harleen1996");
		loginPage.setPassword("viveksingla");
		loginPage.clickSignIn();
	}

	@Then("^User should not be logged in$")
	public void user_should_not_be_logged_in() throws Throwable {
		/*String actualTitle=driver.getTitle();
		String expectedTitle="Sign in to GitHub � GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();*/
		String actualMessage=loginPage.getActualErrorMessage();
		String expectedMessage="Incorrect username or password.";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^User enter wrong username and correct password$")
	public void user_enter_wrong_username_and_correct_password() throws Throwable {
		/*By by=By.name("login");
		WebElement searchTxt=driver.findElement(by);
		searchTxt.sendKeys("harleen");
		by=By.name("password");
		searchTxt=driver.findElement(by);
		searchTxt.sendKeys("viveksingla123");
		searchTxt.submit();*/
		loginPage.setUsername("Harleen");
		loginPage.setPassword("viveksingla123");
		loginPage.clickSignIn();
	}


}
