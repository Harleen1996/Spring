package com.capgemini.banking.daoservices;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgemini.banking.beans.Transaction;
public interface TransactionDAO extends JpaRepository<Transaction, Integer> {
	@Query("SELECT t FROM Transaction t WHERE t.account.accountNo = :accountNo")
	public List<Transaction> findAllTransactions(@Param("accountNo") int accountNo);
}
