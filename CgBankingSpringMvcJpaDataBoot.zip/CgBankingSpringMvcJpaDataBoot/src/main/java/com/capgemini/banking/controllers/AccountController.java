package com.capgemini.banking.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.banking.beans.Account;
import com.capgemini.banking.beans.Transaction;
import com.capgemini.banking.daoservices.AccountDAO;
import com.capgemini.banking.exceptions.AccountBlockedException;
import com.capgemini.banking.exceptions.AccountNotFoundException;
import com.capgemini.banking.exceptions.BankingServicesDownException;
import com.capgemini.banking.exceptions.InsufficientAmountException;
import com.capgemini.banking.exceptions.InvalidAccountTypeException;
import com.capgemini.banking.exceptions.InvalidAmountException;
import com.capgemini.banking.exceptions.InvalidPinNumberException;
import com.capgemini.banking.services.BankingServices;

@Controller
@Scope("session")
public class AccountController {
	@Autowired
	private BankingServices bankingServices;
	
	@RequestMapping("/loginAccount")
	public ModelAndView loginToAccount(@Valid @ModelAttribute Account account, BindingResult bindingResult, HttpServletRequest request) {
		try {
			if (bindingResult.hasErrors())
				return new ModelAndView("loginPage");
			if (account.getAccountNo()==915685001 && account.getPinNumber()==1234)
				return new ModelAndView("adminPage");
			Account accountFromDatabase = bankingServices.getAccountDetails(account.getAccountNo());
			if (account.getPinNumber() != accountFromDatabase.getPinNumber())
				return new ModelAndView("loginPage", "errorMessage", "Invalid Pin Number");
			request.getSession(false).setAttribute("account", accountFromDatabase);
			return new ModelAndView("welcomePage", "account", accountFromDatabase); 
		} catch (NoSuchElementException e) {
			return new ModelAndView("loginPage", "errorMessage", "No such account");
		} catch (AccountNotFoundException | BankingServicesDownException e) {
			return new ModelAndView("loginPage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/accountOpen")
	public ModelAndView registerUserAccount(@Valid @ModelAttribute Account account, BindingResult result) {
		try {
			if (result.hasErrors())
				return new ModelAndView("accountOpeningPage");
			account = bankingServices.openAccount(account);
			return new ModelAndView("accountOpeningSuccessfulPage", "account",  account);
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException e) {
			return new ModelAndView("accountOpeningPage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/depositToAccount")
	public ModelAndView depositToUserAccount(@Valid @ModelAttribute Account account, BindingResult result, @Valid @ModelAttribute Transaction transaction, BindingResult result2, HttpServletRequest request ) {
		try {
			if (result.hasErrors())
				return new ModelAndView("");
			account = bankingServices.depositAmount(((Account) request.getSession(false).getAttribute("account")).getAccountNo(), transaction.getAmount());
			ModelAndView model = new ModelAndView("depositToAccountPage");
			model.addObject("account",  account);
			model.addObject("resultMessage", "Amount deposited to account! Your current account balance is Rs. " + account.getAccountBalance());
			return model;
		} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {
			return new ModelAndView("depositToAccountPage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/withdrawFromAccount")
	public ModelAndView withdrawFromUserAccount(@Valid @ModelAttribute Account account, BindingResult result, HttpServletRequest request ) {
		try {
			if (result.hasErrors())
				return new ModelAndView("");
			account = bankingServices.withdrawAmount(((Account) request.getSession(false).getAttribute("account")).getAccountNo(), account.getTransactions().get(0).getAmount(), account.getPinNumber());
			ModelAndView model = new ModelAndView("withdrawFromAccountPage");
			model.addObject("account",  account);
			model.addObject("resultMessage", "Amount withdrawn from account! Your current account balance is Rs. " + account.getAccountBalance());
			return model;
		} catch (NoSuchElementException e) {
			return new ModelAndView("withdrawFromAccountPage", "errorMessage", "Receipent Account Not Found");
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException | BankingServicesDownException | AccountBlockedException e) {
			return new ModelAndView("withdrawFromAccountPage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/transferToAccount")
	public ModelAndView transferToOtherAccount(@Valid @ModelAttribute Account account, BindingResult result, HttpServletRequest request ) {
		try {
			if (result.hasErrors())
				return new ModelAndView("");
			bankingServices.fundTransfer(account.getAccountNo(), ((Account) request.getSession(false).getAttribute("account")).getAccountNo(), account.getTransactions().get(0).getAmount(), account.getPinNumber());
			return new ModelAndView("fundsTransferPage", "resultMessage", "Amount transferred!");
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException | BankingServicesDownException | AccountBlockedException e) {
			return new ModelAndView("fundsTransferPage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/singleAccount")
	public ModelAndView getSingleAccountDetails(HttpServletRequest request ) throws AccountNotFoundException, BankingServicesDownException {
		Account account = bankingServices.getAccountDetails(((Account)request.getSession(false).getAttribute("account")).getAccountNo());
		ModelAndView model = new ModelAndView("getSingleAssociateDetailsPage");
		model.addObject("account",  account);
		if (account==null)	model.addObject("errorMessage", "No Account found!");
		return model;
	}
	
	@RequestMapping("/updatePin")
	public ModelAndView updateAccountPin(@RequestParam("oldPin") int oldPin, @RequestParam("newPin") int newPin, @RequestParam("confirmNewPin") int confirmNewPin,  HttpServletRequest request) {
		try {
			Account account = bankingServices.getAccountDetails(((Account)request.getSession(false).getAttribute("account")).getAccountNo());
			ModelAndView model = new ModelAndView("customerCarePage");
			if (newPin != confirmNewPin)
				model.addObject("errorMessage","New Pin and Confirm New Pin do not match!");
			else if (oldPin != account.getPinNumber())
				model.addObject("errorMessage","Enter a valid Old Pin!");
			else {
				bankingServices.changeAccountPin(((Account)request.getSession(false).getAttribute("account")).getAccountNo(), newPin);
				model.addObject("resultMessage", "Pin Number Updated!");
			}
			return model;
		} catch (AccountNotFoundException | BankingServicesDownException e) {
			return new ModelAndView("customerCarePage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/updateAccountStatus")
	public ModelAndView updateAccountStatus(HttpServletRequest request) {
		try {
			Account account = bankingServices.getAccountDetails(((Account)request.getSession(false).getAttribute("account")).getAccountNo());
			bankingServices.accountStatus(account.getAccountNo());
			return new ModelAndView("customerCarePage","resultMessage","Your account status would be updated within 24 hours.");
		} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {
			return new ModelAndView("customerCarePage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/deactivateAccount")
	public ModelAndView deactivateUserAccount(@RequestParam("pinNumber") int pinNumber, HttpServletRequest request) {
		try {
			Account account = bankingServices.getAccountDetails(((Account)request.getSession(false).getAttribute("account")).getAccountNo());
			bankingServices.deactivateAccount(account.getAccountNo(),	 pinNumber);
			return new ModelAndView("customerCarePage", "resultMessage", "Account deactivated successfully");
		} catch (AccountNotFoundException | BankingServicesDownException | InvalidPinNumberException e) {
			return new ModelAndView("customerCarePage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/adminGetAllAccounts")
	public ModelAndView adminGetAllAccounts() {
		try {
			List<Account> accounts = bankingServices.getAllAccountDetails();
			/*Map<Integer, Account> allAccountData = new HashMap<>();
			for (Account account : accounts) {
				allAccountData.put(account.getAccountNo(), account);
			}
			return new ModelAndView("PdfRevenueSummary", "accountMap", allAccountData);*/
			ModelAndView model = new ModelAndView("adminPage");
			model.addObject("requestAllAccounts", 1);
			model.addObject("accountList", accounts);
			model.addObject("account", new Account());
			return model;
		} catch (BankingServicesDownException | AccountNotFoundException e) {
			return new ModelAndView("adminPage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/singleAccountTransactions")
	public ModelAndView getSingleAccountTransactionDetails(@ModelAttribute Account account) {
		try {
			List<Transaction> transactions = bankingServices.getAccountAllTransaction(account.getAccountNo());
			ModelAndView model = new ModelAndView("adminPage");
			model.addObject("requestAccountTransactions",1);
			model.addObject("transactions", transactions);
			if (transactions==null)	model.addObject("errorMessage", "No account Transactions!");
			return model;
		} catch (BankingServicesDownException | AccountNotFoundException e) {
			return new ModelAndView("adminPage", "errorMessage", e.getMessage());
		}
	}
	
	@RequestMapping("/adminSingleAccount")
	public ModelAndView getAdminSingleAccountDetails(@ModelAttribute Account account) {
		try {
			ModelAndView model = new ModelAndView("adminPage");
			model.addObject("requestSingleAccount",1);
			account = bankingServices.getAccountDetails(account.getAccountNo());
			model.addObject("account",  account);
			if (account==null)	model.addObject("errorMessage", "Amount not withdrawn!");
			else		model.addObject("resultMessage", "Amount withdrawn from account!");
			return model;
		}	catch (NoSuchElementException e) {
			return new ModelAndView("adminPage", "errorMessage", "Enter valid account number");
		} catch (AccountNotFoundException | BankingServicesDownException e) {
			return new ModelAndView("adminPage", "errorMessage", e.getMessage());
		}
	}
	
}
