package com.capgemini.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.capgemini.banking.beans.Account;
import com.capgemini.banking.beans.Transaction;

@Controller
public class URIController {
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/header")
	public String getHeaderPage() {
		return "headerPage";
	}
	@RequestMapping("/login")
	public String getLoginPage() {
		return "loginPage";
	}
	@RequestMapping("/openAccount")
	public String getAccountOpeningPage() {
		return "accountOpeningPage";
	}
	@RequestMapping("/accountOpeningSuccessful")
	public String getAccountOpeningSuccessfulPage() {
		return "accountOpeningSuccessfulPage";
	}
	@RequestMapping("/welcome")
	public String getWelcomePage() {
		return "welcomePage";
	}
	@RequestMapping("/deposit")
	public String getDepositToAccountPage() {
		return "depositToAccountPage";
	}
	@RequestMapping("/withdraw")
	public String getWithdrawFromAccountPage() {
		return "withdrawFromAccountPage";
	}
	@RequestMapping("/transfer")
	public String getFundsTransferPage() {
		return "fundsTransferPage";
	}
	@RequestMapping("/customerCare")
	public String getCustomerCarePage() {
		return "customerCarePage";
	}
	
	@ModelAttribute
	public Account getAccount() {
		return new Account();
	}
	
	@ModelAttribute
	public Transaction getTransaction() {
		return new Transaction();
	}

}
