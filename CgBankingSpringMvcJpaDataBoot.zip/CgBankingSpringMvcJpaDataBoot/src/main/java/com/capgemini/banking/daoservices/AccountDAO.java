package com.capgemini.banking.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import com.capgemini.banking.beans.Account;
public interface AccountDAO extends JpaRepository<Account, Integer> {}