package com.cg.project.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.project.beans.Transaction;

public interface TransactionDAO extends JpaRepository<Transaction, Integer> {
}
