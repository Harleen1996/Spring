package com.cg.mobilebilling.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;

public class CustomerController {
	@Autowired
	private BillingServices billingServices;
	
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException   {
		int customerID = billingServices.acceptCustomerDetails(customer.getFirstName(), customer.getLastName(), customer.getEmailID(), customer.getDateOfBirth(), "Delhi", "Delhi", 110007);
		return new ModelAndView("index", "customerID", customerID);
	}
	/*
	@RequestMapping("planDetails")
	public ModelAndView planDdetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getPlanAllDetailsPage");
				return null;
				
			}
	
	@RequestMapping("openPostpaidAccount")
	public ModelAndView openPostpaidAccountAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getPlanAllDetailsPage");
				return null;
				
			}
	
	@RequestMapping("customerDetails")
	public ModelAndView customerDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getCustomerDetailsPage");
				return null;
				
			}
	
	@RequestMapping("allCustomerDetails")
	public ModelAndView allCustomerDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getAllCustomerDetailsPage");
				return null;
				
			}
	
	@RequestMapping("postpaidAccountDetails")
	public ModelAndView postpaidAccountDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getPostPaidAccountDetailsPage");
				return null;
				
			}
	
	
	@RequestMapping("deleteCustomerAccount")
	public ModelAndView deleteCustomerAccountAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("deleteCustomerPage");
				return null;
				
			}
	
	@RequestMapping("customerPostPaidAccountPlanDetails")
	public ModelAndView customerPostPaidAccountPlanDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getCustomerPostPaidAccountPlanDetailsPage");
				return null;
				
			}
	
	@RequestMapping("planChange")
	public ModelAndView planChangeAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("changePlanPage");
				return null;
				
			}
	
	@RequestMapping("mobileBillDetails")
	public ModelAndView mobileBillDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getMobileBillDetailsPage");
				return null;
				
			}
	
	@RequestMapping("customerPostPaidAccountAllBillDetails")
	public ModelAndView customerPostPaidAccountAllBillDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getCustomerPostPaidAccountAllBillDetailsPage");
				return null;
				
			}
	
	@RequestMapping("generateMonthlyBill")
	public ModelAndView generateMonthlyMobileAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("generateMonthlyMobileBillPage");
				return null;
				
			}*/
}
