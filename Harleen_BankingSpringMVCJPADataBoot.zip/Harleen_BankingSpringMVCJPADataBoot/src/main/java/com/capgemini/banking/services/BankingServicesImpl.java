package com.capgemini.banking.services;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.banking.beans.Account;
import com.capgemini.banking.beans.Transaction;
import com.capgemini.banking.daoservices.AccountDAO;
import com.capgemini.banking.daoservices.TransactionDAO;
import com.capgemini.banking.exceptions.AccountBlockedException;
import com.capgemini.banking.exceptions.AccountNotFoundException;
import com.capgemini.banking.exceptions.BankingServicesDownException;
import com.capgemini.banking.exceptions.InsufficientAmountException;
import com.capgemini.banking.exceptions.InvalidAccountTypeException;
import com.capgemini.banking.exceptions.InvalidAmountException;
import com.capgemini.banking.exceptions.InvalidPinNumberException;

@Component(value="bankingServices")
public class BankingServicesImpl implements BankingServices {
	
	@Autowired
	private AccountDAO accountDAO;
	
	@Autowired
	private TransactionDAO transactionDAO;

	@Override
	public int openAccount(String firstName, String lastName, String accountType, float accountBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
			if (!(accountType.equalsIgnoreCase("Savings") || accountType.equalsIgnoreCase("Current")))
				throw new InvalidAccountTypeException("Invalid account type. Please select among (Savings / Current) account type.");
			if (accountBalance<1000)
				throw new InvalidAmountException("Insufficient initial balance. Minimum balance of Rs. 1000 must be added");
			Account account = new Account(firstName, lastName, accountType, accountBalance, 0000);
			List<Transaction> transactions = new ArrayList<>();
			transactions.add(new Transaction(accountBalance, "Deposit", account));
			account.setTransactions(transactions);
			account = accountDAO.save(account);
			if (account == null)	throw new BankingServicesDownException("Banking Services are Down. Please try again later.");
			return account.getAccountNo();
	}

	@Override
	public float depositAmount(int accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
			Account account = accountDAO.findById(accountNo).get();
			if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			account.setAccountBalance(account.getAccountBalance()+amount);
			account = accountDAO.save(account);
			Transaction transaction=new Transaction(amount, "Deposit", account);
			transactionDAO.save(transaction);
			return account.getAccountBalance(); 	
	}

	@Override
	public float withdrawAmount(int accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
			Account account = accountDAO.findById(accountNo).get();
			if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			if (account.getStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
			if (account.getPinNumber()!=pinNumber)		throw new InvalidPinNumberException("The pin entered is invalid. Please enter a valid pin");
			if (account.getAccountBalance()-amount<1000)	throw new InsufficientAmountException("The transaction got failed due to insufficient balance in the account.");
			account.setAccountBalance(account.getAccountBalance()-amount);
			account = accountDAO.save(account);
			Transaction transaction=new Transaction(amount, "Withdraw", account);
			transactionDAO.save(transaction);
			return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(int accountNoTo, int accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
			if (accountDAO.findById(accountNoTo).get()==null)	throw new AccountNotFoundException("The Receipent's Account does not exists");
			if (accountDAO.findById(accountNoFrom).get()==null)	throw new AccountNotFoundException("The Sender Account does not exists");
			if (accountNoTo == accountNoFrom)	throw new AccountNotFoundException("The Receipent's Account cannot be same as Sender's Account.");
			if (accountDAO.findById(accountNoFrom).get().getStatus().equalsIgnoreCase("Blocked"))	throw new AccountBlockedException("The sender account is blocked.");
			if (accountDAO.findById(accountNoFrom).get().getAccountBalance()-transferAmount<1000)	throw new InsufficientAmountException("The transaction got failed due to insufficient balance in the account.");
			withdrawAmount(accountNoFrom, transferAmount, pinNumber);
			depositAmount(accountNoTo, transferAmount);
			return true;
	}

	@Override
	public Account getAccountDetails(int accountNo) throws AccountNotFoundException, BankingServicesDownException {
			Account account = accountDAO.findById(accountNo).get();
			if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			return account;
	}

	@Override
	public Account loginAccounDetails(int accountNo) throws AccountNotFoundException, AccountBlockedException {
		Account account = accountDAO.findById(accountNo).get();
		if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException, AccountNotFoundException {
		List<Account> accounts = accountDAO.findAll();
		if (accounts == null)		throw new AccountNotFoundException("No Accounts Found!");
		return accounts;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
			List<Transaction> transactions = transactionDAO.findAllTransactions(accountNo);
			if (transactions == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			return transactions;
	}

	@Override
	public String accountStatus(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
			Account account =  accountDAO.findById(accountNo).get();
			if (account == null) throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			return account.getStatus();
	}
	
	@Override
	public boolean changeAccountPin(int accountNo, int pinNumber) throws AccountNotFoundException, BankingServicesDownException{
			Account account =  accountDAO.findById(accountNo).get();
			if (account==null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");	
			account.setPinNumber(pinNumber);
			accountDAO.save(account);
			return true;
	}
	
	@Override
	public void changeAccountStatus(int accountNo, String status)
			throws BankingServicesDownException, AccountNotFoundException {
		Account account =  accountDAO.findById(accountNo).get();
		if (account == null) throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
		account.setStatus(status);
		accountDAO.save(account);
	}

	@Override
	public boolean upblockAccount(int accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
			Account account = accountDAO.findById(accountNo).get();
			if (account==null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			account.setStatus("Active");
			accountDAO.save(account);
			return true;
	}

	@Override
	public boolean deactivateAccount(int accountNo, int pinNumber)
			throws AccountNotFoundException, BankingServicesDownException, InvalidPinNumberException {
			Account account = accountDAO.findById(accountNo).get(); 
			if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			if (account.getPinNumber() != pinNumber)	throw new InvalidPinNumberException("The pin entered is invalid. Please enter a valid pin");
			accountDAO.deleteById(accountNo);
			return true;
	}
}
