package com.cg.mobilebilling.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostPaidDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private BillingDAOServices billingDAOServices;
	@Autowired
	private PostPaidDAOServices postPaidDAOServices;
	@Autowired
	private CustomerDAOServices customerDAOServices;
	@Autowired
	private PlanDAOServices planDAOServices; 
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		return planDAOServices.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException {
		customer=customerDAOServices.save(customer);
		//String firstName, String lastName, String emailID, String dateOfBirth,
		//String billingAddressCity, String billingAddressState, int billingAddressPinCode
		return customer;
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOServices.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Customer with customer id "+customerID+" does not exist");
		Plan plan=planDAOServices.findById(planID).get();
		if(plan==null) throw new PlanDetailsNotFoundException("Plan with plan id "+planID+" does not exist");
		PostpaidAccount postpaidAccount=new PostpaidAccount(plan, customer);
		postpaidAccount=postPaidDAOServices.save(postpaidAccount);
		return postpaidAccount.getMobileNo();
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOServices.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Customer with customer id "+customerID+" does not exist");
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAOServices.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount=postPaidDAOServices.findById(mobileNo).get();
		if(postpaidAccount==null) throw new PostpaidAccountNotFoundException("Post Paid Account does not exist");
		return postpaidAccount;
	}
	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		getPostPaidAccountDetails(customerID, mobileNo);
		openPostpaidMobileAccount(customerID, planID);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		getCustomerDetails(customerID);
		getPostPaidAccountDetails(customerID, mobileNo);
		postPaidDAOServices.deleteById(mobileNo);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		getCustomerDetails(customerID);
		customerDAOServices.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		return (getPostPaidAccountDetails(customerID, mobileNo)).getPlan();
	}
	@Override
	public Plan savingNewPlanInTable(Plan plan){
		plan=planDAOServices.save(plan);
		return plan;
	}
}