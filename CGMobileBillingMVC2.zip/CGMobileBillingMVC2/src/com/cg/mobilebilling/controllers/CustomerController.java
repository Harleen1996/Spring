package com.cg.mobilebilling.controllers;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class CustomerController {
	@Autowired
	private BillingServices billingServices;
	@RequestMapping("/acceptCustomerDetails")
	public ModelAndView acceptCustomerDetails(@Valid @ModelAttribute Customer customer,BindingResult result) throws BillingServicesDownException {
		if(result.hasErrors()) 
			return new ModelAndView("acceptCustomerDetailsPage");
		customer=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("newAccepCustomerDetailsPage","customer",customer);
	}
}
