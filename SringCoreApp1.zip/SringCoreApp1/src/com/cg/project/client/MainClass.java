package com.cg.project.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.project.services.GreetingServices;
import com.cg.project.services.GreetingServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("projectbeans.xml");
		GreetingServices greetingServices= (GreetingServices) context.getBean("greetingServices");
		
		//greetingServices.sayHello("Harleen Aggarwal");
		greetingServices.greetUser("Harleen Aggarwal");
	}

}
