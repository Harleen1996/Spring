package com.cg.project.services;

import org.springframework.stereotype.Component;


public class GreetingServicesImpl2 implements GreetingServices{

	@Override
	public void greetUser(String name) {
		System.out.println("Hello "+name);
		
	}

}
