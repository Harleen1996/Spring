package com.cg.project.services;

public interface GreetingServices{
	//void sayHello(String name);
	void greetUser(String name);

}
