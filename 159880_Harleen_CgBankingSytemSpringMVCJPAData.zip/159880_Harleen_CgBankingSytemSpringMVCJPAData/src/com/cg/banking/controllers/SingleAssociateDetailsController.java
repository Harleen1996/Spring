package com.cg.banking.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;

@Controller
public class SingleAssociateDetailsController {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/SingleAssociateDetails")
	public ModelAndView registerAssociateAction(HttpServletRequest request) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException{
        HttpSession session=request.getSession(false);
        int accountNo= (Integer)session.getAttribute("accountNo");
		Account account=bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("getSingleAssociateDetailsPage", "account", account);
	}
}
