package com.cg.banking.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class PinUpdate {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/PinUpdate")
	public ModelAndView registerAssociateAction(@RequestParam("oldPinText") int oldPinText,@RequestParam("newPinText") int newPinText,
			@RequestParam("confirmPinText") int confirmPinText ,HttpServletRequest request) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
        HttpSession session=request.getSession(false);
        int accountNo=(Integer)session.getAttribute("accountNo");
        if (newPinText != confirmPinText)
        	return new ModelAndView("customerCarePage","errorMessage1", "New Pin and Confirm New Pin fields do not match!");
        Account account=bankingServices.getAccountDetails(accountNo);
        if (oldPinText != account.getPinNumber())
        	return new ModelAndView("customerCarePage","errorMessage1", "You entered wrong pin number");
        account.setPinNumber(newPinText);
        bankingServices.changeAccountPin(account);
		return new ModelAndView("customerCarePage", "resultMessage1", "Pin Number Changed Successfully");
	}
}
