package com.cg.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

@Controller
public class URIController {
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/headerPage")
	public String getRegistrationPage() {
		return "headerPage";
	}
	
	@RequestMapping("/loginPage")
	public String getLoginPage() {
		return "loginPage";
	}
	
	@RequestMapping("/accountOpeningPage")
	public String getAccountOpeningPage() {
		return "accountOpeningPage";
	}
	
	@RequestMapping("/accountOpeningSuccessfulPage")
	public String getAccountOpeningSuccessfulPage() {
		return "accountOpeningSuccessfulPage";
	}
	
	@RequestMapping("/pinUpdationPage")
	public String getPinUpdationPage() {
		return "pinUpdationPage";
	}
	
	@RequestMapping("/welcomePage")
	public String getWelcomePage() {
		return "welcomePage";
	}
	
	@RequestMapping("/depositToAccountPage")
	public String getDepositToAccountPage() {
		return "depositToAccountPage";
	}
	
	@RequestMapping("/withdrawFromAccountPage")
	public String getWithdrawFromAccountPage() {
		return "withdrawFromAccountPage";
	}
	
	@RequestMapping("/fundsTransferPage")
	public String getFundsTransferPage() {
		return "fundsTransferPage";
	}
	
	@RequestMapping("/customerCarePage")
	public String getCustomerCarePage() {
		return "customerCarePage";
	}
	
	@RequestMapping("/getSingleAssociateDetailsPage")
	public String getSingleAssociateDetailsPage() {
		return "getSingleAssociateDetailsPage";
	}
	
	@ModelAttribute
	public Account getAccount() {
		Account account= new Account();
		return account;
	}
	
	@ModelAttribute
	public Transaction getTransaction() {
		Transaction transaction= new Transaction();
		return transaction;
	}
}
