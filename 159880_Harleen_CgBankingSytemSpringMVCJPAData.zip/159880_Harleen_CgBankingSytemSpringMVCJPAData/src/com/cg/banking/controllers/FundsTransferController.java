package com.cg.banking.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class FundsTransferController {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/FundsTransfer")
	public ModelAndView registerAssociateAction(@RequestParam("accountNoTo") int accountNoTo,@RequestParam("transferAmount") int transferAmount,
			@RequestParam("pinNumber") int pinNumber ,HttpServletRequest request) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
        HttpSession session=request.getSession(false);
        try {
			int accountNoFrom=(Integer)session.getAttribute("accountNo");
			int accountBalance=bankingServices.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
			return new ModelAndView("fundsTransferPage", "resultMessage", "The fund transfer is Successful! The updated Account Balance = Rs. " + accountBalance);
		} catch (BankingServicesDownException| AccountNotFoundException|
				AccountBlockedException| InsufficientAmountException| InvalidPinNumberException e) {
			return new ModelAndView("fundsTransferPage", "errorMessage", e.getMessage());
		}
	}
}
