package com.cg.banking.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;

@Controller
public class LoginController {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/LoginPage")
	public ModelAndView registerAssociateAction(@Valid @ModelAttribute Account account,BindingResult result,HttpServletRequest request) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException{
		try {
			Account account1=bankingServices.getAccountDetails(account.getAccountNo());
			if(account1.getPinNumber() != account.getPinNumber())
				return new ModelAndView("loginPage", "message", "Pin Number does not match");
			else {
			HttpSession session=request.getSession();
			 session.setAttribute("accountNo", account.getAccountNo());
			 if(result.hasErrors())
				return new ModelAndView("loginPage");
			account=bankingServices.getAccountDetails(account.getAccountNo());
			return new ModelAndView("welcomePage", "account", account);
			}
		} catch (AccountNotFoundException e) {
			return new ModelAndView("loginPage", "message", e.getMessage());
		}
	}
}
