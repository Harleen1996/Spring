package com.cg.banking.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;

@Controller
public class OpenAccountController {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/openAccount")
	public ModelAndView registerAssociateAction(@Valid @ModelAttribute Account account,BindingResult result) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException{
		
		if(result.hasErrors())
			return new ModelAndView("accountOpeningPage");
		account=bankingServices.openAccount(account);
		return new ModelAndView("accountOpeningSuccessfulPage", "account", account);
	}
}
