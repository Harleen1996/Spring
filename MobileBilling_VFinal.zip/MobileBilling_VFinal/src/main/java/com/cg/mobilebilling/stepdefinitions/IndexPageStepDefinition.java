package com.cg.mobilebilling.stepdefinitions;

import static org.assertj.core.api.Assertions.in;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.IndexPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class IndexPageStepDefinition {

	private IndexPage indexPage;
	private WebDriver driver;

	@Given("^User is on index Page$")
	public void user_is_on_index_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/");
		
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^User clicks on Open Account link$")
	public void user_clicks_on_Open_Account_link() throws Throwable {
	indexPage.clickNewCustomerOpenAccount();
	}

	@Then("^User is redirected to registration page$")
	public void user_is_redirected_to_registration_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Plan Details link$")
	public void user_clicks_on_Plan_Details_link() throws Throwable {
	indexPage.clickExistingPlanDetails();
	}

	@Then("^User is redirected to getPlanAllDetails page$")
	public void user_is_redirected_to_getPlanAllDetails_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="All Plan Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Open Post Paid Mobile Account link$")
	public void user_clicks_on_Open_Post_Paid_Mobile_Account_link() throws Throwable {
	    indexPage.clickOpenPostpaidMobileAccount();
	}

	@Then("^User is redirected to openPostpaidMobileAccount page$")
	public void user_is_redirected_to_openPostpaidMobileAccount_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Open Postpaid Mobile Account";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Generate Monthly Mobile Bill link$")
	public void user_clicks_on_Generate_Monthly_Mobile_Bill_link() throws Throwable {
	  indexPage.clickToGenerateMonthlyMobileBill();
	}

	@Then("^User is redirected to generateMonthlyMobileBill page$")
	public void user_is_redirected_to_generateMonthlyMobileBill_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Generate Monthly Mobile Bill";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Customer Details link$")
	public void user_clicks_on_Customer_Details_link() throws Throwable {
		indexPage.clickParticularCustomerDetails();
	}

	@Then("^User is redirected to getCustomerDetails page$")
	public void user_is_redirected_to_getCustomerDetails_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Customer details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on All Customer Details link$")
	public void user_clicks_on_All_Customer_Details_link() throws Throwable {
	indexPage.clickAllExistingCustomers();
	}

	@Then("^User is redirected to getAllCustomerDetails page$")
	public void user_is_redirected_to_getAllCustomerDetails_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="All Customer details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Get Post Paid Account Details link$")
	public void user_clicks_on_Get_Post_Paid_Account_Details_link() throws Throwable {
	    indexPage.clickGetPostpaidAccountDetails();
	}

	@Then("^User is redirected to getPostPaidAccountDetails page$")
	public void user_is_redirected_to_getPostPaidAccountDetails_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Postpaid Account Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Get Customer All Post Paid Account Details link$")
	public void user_clicks_on_Get_Customer_All_Post_Paid_Account_Details_link() throws Throwable {
	   indexPage.clickGetCustomerPostpaidAccountDetails();
	}

	@Then("^User is redirected to getCustomerAllPostpaidAccountsDetails page$")
	public void user_is_redirected_to_getCustomerAllPostpaidAccountsDetails_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Customer All Postpaid Account Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Mobile Bill Details link$")
	public void user_clicks_on_Mobile_Bill_Details_link() throws Throwable {
	    indexPage.clickMonthlyMobileBillDetailsInPdf();
	}

	@Then("^User is redirected to getMobileBillDetails page$")
	public void user_is_redirected_to_getMobileBillDetails_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Mobile Bill details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Customer Postpaid Account All Bill Details link$")
	public void user_clicks_on_Customer_Postpaid_Account_All_Bill_Details_link() throws Throwable {
	  indexPage.clickCustomerPostpaidAccountAllBills();
	}

	@Then("^User is redirected to getCustomerPostPaidAccountAllBillDetails page$")
	public void user_is_redirected_to_getCustomerPostPaidAccountAllBillDetails_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Customer Postpaid Account All Bill Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Change Plan link$")
	public void user_clicks_on_Change_Plan_link() throws Throwable {
	   indexPage.clickToChangePlan();
	}

	@Then("^User is redirected to changePlan page$")
	public void user_is_redirected_to_changePlan_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Change Plan";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Delete Customer link$")
	public void user_clicks_on_Delete_Customer_link() throws Throwable {
	  indexPage.clickDeleteCustomerRecord();
	}

	@Then("^User is redirected to deleteCustomer page$")
	public void user_is_redirected_to_deleteCustomer_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Delete Customer Record";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Close Customer PostPaid Account link$")
	public void user_clicks_on_Close_Customer_PostPaid_Account_link() throws Throwable {
	  indexPage.clickCloseAParticularPostpaidAccount();
	}

	@Then("^User is redirected to closeCustomerPostPaidAccount page$")
	public void user_is_redirected_to_closeCustomerPostPaidAccount_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Close A Postpaid Account";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on Customer Postpaid Account Plan Details link$")
	public void user_clicks_on_Customer_Postpaid_Account_Plan_Details_link() throws Throwable {
	   indexPage.clickGetCustomerPostpaidAccountPlanDetails();
	}

	@Then("^User is redirected to getCustomerPostPaidAccountPlanDetails page$")
	public void user_is_redirected_to_getCustomerPostPaidAccountPlanDetails_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Customer Postpaid Account Plan Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on add plans link$")
	public void user_clicks_on_add_plans_link() throws Throwable {
	 indexPage.clickAddPlansForAdmin();
	}

	@Then("^User is redirected to addPlans page$")
	public void user_is_redirected_to_addPlans_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Add New Plan";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

}
