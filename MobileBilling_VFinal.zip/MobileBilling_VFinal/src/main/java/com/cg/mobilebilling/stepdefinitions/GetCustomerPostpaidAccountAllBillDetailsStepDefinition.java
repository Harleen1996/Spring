package com.cg.mobilebilling.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetCustomerPostpaidAccountAllBillDetailsStepDefinition {

	@Given("^User is on getCustomerPostPaidAccountAllBillDetailsPage Page$")
	public void user_is_on_getCustomerPostPaidAccountAllBillDetailsPage_Page() throws Throwable {

	}

	@When("^User enter his correct credentials and click on postpaid account all bill details button$")
	public void user_enter_his_correct_credentials_and_click_on_postpaid_account_all_bill_details_button() throws Throwable {

	}

	@Then("^Pdf is generated displaying all the details$")
	public void pdf_is_generated_displaying_all_the_details() throws Throwable {

	}

	@Given("^User is on getCustomerPostPaidAccountAllBillDetailsPages Page$")
	public void user_is_on_getCustomerPostPaidAccountAllBillDetailsPages_Page() throws Throwable {

	}

	@When("^User click on home page button of getCustomerPostPaidAccountAllBillDetailsPages$")
	public void user_click_on_home_page_button_of_getCustomerPostPaidAccountAllBillDetailsPages() throws Throwable {

	}

	@Then("^User is redirected to home page from getCustomerPostPaidAccountAllBillDetailsPages$")
	public void user_is_redirected_to_home_page_from_getCustomerPostPaidAccountAllBillDetailsPages() throws Throwable {

	}

}
