package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ChangePlan {
	
	@FindBy(how=How.ID,id="customerID")
	private WebElement customerID;
	
	@FindBy(how=How.NAME,name="mobileNo")
	private WebElement mobileNo;
	
	@FindBy(how=How.NAME, name="planID")
	private WebElement planID;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"customer\"]/table/tbody/tr[5]/td/input")
	private WebElement submit;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/font")
	private WebElement message;

	public ChangePlan() {
		super();
	}

	public String getCustomerID() {
		return customerID.getAttribute("value");
	}

	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}

	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public String getMessage() {
		return message.getText();
	}

	public String getPlanID() {
		return planID.getAttribute("value");
	}

	public void setPlanID(String planID) {
		this.planID.sendKeys(planID);
	}

	public void clickSubmit() {
		submit.click();
	}
	
	
}
