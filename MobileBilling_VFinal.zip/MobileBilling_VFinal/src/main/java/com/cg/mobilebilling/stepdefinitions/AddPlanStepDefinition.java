package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.AddPlanPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class AddPlanStepDefinition {
	
	private AddPlanPage addPlanPage;
	private WebDriver driver;
	
	@Given("^User is on addPlansPage Page$")
	public void user_is_on_addPlansPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/addPlans");
		
		addPlanPage=PageFactory.initElements(driver, AddPlanPage.class);
	}

	@When("^User enter the details and click on submit button$")
	public void user_enter_the_details_and_click_on_submit_button() throws Throwable {
	    addPlanPage.setMonthlyRental("");
	    addPlanPage.setFreeLocalCalls("200");
	    addPlanPage.setFreeStdCalls("100");
		addPlanPage.setFreeInternetDataUsageUnits("2048");
	    addPlanPage.setLocalCallRate("0.2");
	    addPlanPage.setStdCallRate("0.5");
	    addPlanPage.setLocalSMSRate("1");
	    addPlanPage.setStdSMSRate("2");
	    addPlanPage.setInternetDataUsageRate("0.50");
	    addPlanPage.setPlanCircle("Punjab");
	    addPlanPage.setPlanName("Gold");
	    addPlanPage.clickSubmit();
	}

	@Then("^User is redirected to addPlansPage page and message gets displayed$")
	public void user_is_redirected_to_addPlansPage_page_and_message_gets_displayed() throws Throwable {
		String actualMessage=addPlanPage.getAddPlanMessage();
		String planId=actualMessage.substring(actualMessage.length()-4, actualMessage.length());
		String expectedMessage="Plan details added successfully. Plan Id is: " + planId;
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^User click on home page button$")
	public void user_click_on_home_page_button() throws Throwable {
	   addPlanPage.clickHomePage();
	}

	@Then("^User is redirected to home page$")
	public void user_is_redirected_to_home_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Mobile Billing";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}
