package com.cg.mobilebilling.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetCustomerPostpaidAccountPlanDetailsStepDefinition {
	@Given("^User is on getCustomerPostPaidAccountPlanDetailsPage$")
	public void user_is_on_getCustomerPostPaidAccountPlanDetailsPage() throws Throwable {

	}

	@When("^User enter his correct credentials and click on submit button of getCustomerPostPaidAccountPlanDetailsPage$")
	public void user_enter_his_correct_credentials_and_click_on_submit_button_of_getCustomerPostPaidAccountPlanDetailsPage() throws Throwable {

	}

	@Then("^User is redirected to getCustomerPostPaidAccountPlanDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getCustomerPostPaidAccountPlanDetailsPage_page_and_details_gets_displayed() throws Throwable {

	}

	@When("^User click on home page button of getCustomerPostPaidAccountPlanDetailsPage$")
	public void user_click_on_home_page_button_of_getCustomerPostPaidAccountPlanDetailsPage() throws Throwable {

	}

	@Then("^User is redirected to home page from getCustomerPostPaidAccountPlanDetailsPage$")
	public void user_is_redirected_to_home_page_from_getCustomerPostPaidAccountPlanDetailsPage() throws Throwable {

		
	}

}
