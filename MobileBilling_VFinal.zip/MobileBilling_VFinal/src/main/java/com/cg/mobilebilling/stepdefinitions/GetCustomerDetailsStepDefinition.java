package com.cg.mobilebilling.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetCustomerDetailsStepDefinition {

	@Given("^User is on getCustomerDetailsPage Page$")
	public void user_is_on_getCustomerDetailsPage_Page() throws Throwable {

	}

	@When("^User enter his correct credentials and click on submit button of getCustomerDetailsPage$")
	public void user_enter_his_correct_credentials_and_click_on_submit_button_of_getCustomerDetailsPage() throws Throwable {

	}

	@Then("^User is redirected to getCustomerDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getCustomerDetailsPage_page_and_details_gets_displayed() throws Throwable {

	}

	@When("^User click on home page button of getCustomerDetailsPage$")
	public void user_click_on_home_page_button_of_getCustomerDetailsPage() throws Throwable {

	}

	@Then("^User is redirected to home page from getCustomerDetailsPage$")
	public void user_is_redirected_to_home_page_from_getCustomerDetailsPage() throws Throwable {

	}
}
