package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class IndexPage {

	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[1]/td[2]/a")
	private WebElement newCustomerOpenAccount;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[2]/td[2]/a/font")
	private WebElement existingPlanDetails;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[3]/td[2]/a/font")
	private WebElement openPostpaidMobileAccount;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[4]/td[2]/a")
	private WebElement toGenerateMonthlyMobileBill;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[5]/td[2]/a")
	private WebElement particularCustomerDetails;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[6]/td[2]/a")
	private WebElement allExistingCustomers;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[7]/td[2]/a")
	private WebElement getPostpaidAccountDetails;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[8]/td[2]/a")
	private WebElement getCustomerPostpaidAccountDetails;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[9]/td[2]/a")
	private WebElement monthlyMobileBillDetailsInPdf;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[10]/td[2]/a")
	private WebElement customerPostpaidAccountAllBills;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[11]/td[2]/a")
	private WebElement toChangePlan;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[12]/td[2]/a")
	private WebElement deleteCustomerRecord;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[13]/td[2]/a")
	private WebElement closeAParticularPostpaidAccount;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[14]/td[2]/a")
	private WebElement getCustomerPostpaidAccountPlanDetails;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[15]/td[2]/a")
	private WebElement addPlansForAdmin;

	public IndexPage() {
		super();
	}
	
	public void clickNewCustomerOpenAccount() {
		newCustomerOpenAccount.click();
		}
	
	public void clickExistingPlanDetails() {
		existingPlanDetails.click();
		}
	
	public void clickOpenPostpaidMobileAccount() {
		openPostpaidMobileAccount.click();
		}
	
	public void clickToGenerateMonthlyMobileBill() {
		toGenerateMonthlyMobileBill.click();
		}
	
	public void clickParticularCustomerDetails() {
		particularCustomerDetails.click();
		}
	
	public void clickAllExistingCustomers() {
		allExistingCustomers.click();
		}
	
	public void clickGetPostpaidAccountDetails() {
		getPostpaidAccountDetails.click();
		}
	
	public void clickGetCustomerPostpaidAccountDetails() {
		getCustomerPostpaidAccountDetails.click();
		}
	
	public void clickMonthlyMobileBillDetailsInPdf() {
		monthlyMobileBillDetailsInPdf.click();
		}
	
	public void clickCustomerPostpaidAccountAllBills() {
		customerPostpaidAccountAllBills.click();
		}
	
	public void clickToChangePlan() {
		toChangePlan.click();
		}
	
	public void clickDeleteCustomerRecord() {
		deleteCustomerRecord.click();
		}
	
	public void clickCloseAParticularPostpaidAccount() {
		closeAParticularPostpaidAccount.click();
		}
	
	public void clickGetCustomerPostpaidAccountPlanDetails() {
		getCustomerPostpaidAccountPlanDetails.click();
		}
	
	public void clickAddPlansForAdmin() {
		addPlansForAdmin.click();
		}
	
}
