package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.AddPlanPage;
import com.cg.mobilebilling.pagebeans.OpenPostpaidMobileAccount;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class openPostpaidMobileAccountStepDefinition {
	
	private WebDriver driver;
	private OpenPostpaidMobileAccount openPostpaidMobileAccount;

	@Given("^User is on openPostpaidMobileAccountPage Page$")
	public void user_is_on_openPostpaidMobileAccountPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/openPostpaidMobileAccount");
		
		openPostpaidMobileAccount=PageFactory.initElements(driver, OpenPostpaidMobileAccount.class);
	}

	@When("^User enter his correct credentials and click on submit button of openPostpaidMobileAccountPage$")
	public void user_enter_his_correct_credentials_and_click_on_submit_button_of_openPostpaidMobileAccountPage() throws Throwable {
	  openPostpaidMobileAccount.setCustomerID("20024");
	  openPostpaidMobileAccount.setPlanID("1001");
	  openPostpaidMobileAccount.clickSubmit();
	}

	@Then("^User is redirected to openPostpaidMobileAccountPage page and message gets displayed$")
	public void user_is_redirected_to_openPostpaidMobileAccountPage_page_and_message_gets_displayed() throws Throwable {
		String actualMessage=openPostpaidMobileAccount.getMessage();
		String mobileNo=actualMessage.substring(actualMessage.length()-33, actualMessage.length()-23);
		String expectedMessage="Your postpaid account for mobileNo "+mobileNo+" is successfully opened";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^User click on home page button of openPostpaidMobileAccountPage$")
	public void user_click_on_home_page_button_of_openPostpaidMobileAccountPage() throws Throwable {
		openPostpaidMobileAccount.clickHomePage();
	}

	@Then("^User is redirected to home page from openPostpaidMobileAccountPage$")
	public void user_is_redirected_to_home_page_from_openPostpaidMobileAccountPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Mobile Billing";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}
