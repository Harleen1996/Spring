package com.cg.onlineshop.controllers;

public class CustomResponse {
	private int stsatusCode;
	private String responseMessage;
	
	public CustomResponse() {}
	
	public CustomResponse(int stsatusCode, String responseMessage) {
		super();
		this.stsatusCode = stsatusCode;
		this.responseMessage = responseMessage;
	}

	public int getStsatusCode() {
		return stsatusCode;
	}

	public void setStsatusCode(int stsatusCode) {
		this.stsatusCode = stsatusCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	

}
