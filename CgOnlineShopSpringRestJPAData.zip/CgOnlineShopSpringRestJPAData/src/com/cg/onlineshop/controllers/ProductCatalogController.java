package com.cg.onlineshop.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
import com.cg.onlineshop.services.OnlineShoppingServices;

@RestController
public class ProductCatalogController {

	@Autowired
	OnlineShoppingServices OnlineShoppingServices;
	
	@RequestMapping("/hello")
	public ResponseEntity<String> sayHello(){
		ResponseEntity<String> response=new ResponseEntity<String>("Hello to All", HttpStatus.OK);
		return response;
	}
	
	@RequestMapping(value="/acceptProductDetails", method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
		OnlineShoppingServices.acceptProductDetails(product);
		return new ResponseEntity<String>("Product Details Succesfully added", HttpStatus.OK);
		 
	}
	

/*	@RequestMapping(value="/getProductDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> getProductDetails(@ModelAttribute Product product) throws ProductDetailsNotFoundException{
		product=OnlineShoppingServices.getProductDetails(product.getProductId());
		return new ResponseEntity<String>("Product Details"+product,HttpStatus.OK);
		 
	}
	
	@RequestMapping(value="/getAllProductDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> getAllProductDetails(@ModelAttribute Product product) throws ProductDetailsNotFoundException{
		List<Product> products=OnlineShoppingServices.getAllProductDetails();
		return new ResponseEntity<String>("All Products Details"+products, HttpStatus.OK);
		 
	}
	
	
	@RequestMapping(value="/removeProductDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> removeProductDetails(@ModelAttribute Product product) throws ProductDetailsNotFoundException{
		OnlineShoppingServices.removeProductDetails(product.getProductId());
		return new ResponseEntity<String>("Product removed succesfully!", HttpStatus.OK);
		 
	}*/
	@RequestMapping(value="/getProductDetails",produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<Product> getProductDetails(@RequestParam("productId")int productId) throws ProductDetailsNotFoundException{
		Product product=OnlineShoppingServices.getProductDetails(productId);
		return new ResponseEntity<>(product,HttpStatus.OK);
		 
	}
	
	@RequestMapping(value="/getAllProductDetails",method=RequestMethod.GET,consumes=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Product>> getAllProductDetails(){
		List<Product> productsList=OnlineShoppingServices.getAllProductDetails();
		return new ResponseEntity<>(productsList, HttpStatus.OK);
		 
	}
	
	
	@RequestMapping(value="/removeProductDetails",method=RequestMethod.DELETE)
	public ResponseEntity<String> removeProductDetails(@RequestParam("productId")int productId) throws ProductDetailsNotFoundException{
		OnlineShoppingServices.removeProductDetails(productId);
		return new ResponseEntity<String>("Product removed succesfully!", HttpStatus.OK);
		 
	}
}
