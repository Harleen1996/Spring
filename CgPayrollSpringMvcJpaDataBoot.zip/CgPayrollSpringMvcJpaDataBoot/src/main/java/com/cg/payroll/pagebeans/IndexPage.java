package com.cg.payroll.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class IndexPage {
	
	@FindBy(how=How.XPATH,xpath="/html/body/table/tbody/tr/td[2]/a")
	private WebElement button;
	
	public IndexPage() {
		super();
	}

	public void clickSignUp() {
		button.click();
		}
}
