package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.IndexPage;
import com.cg.payroll.pagebeans.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {

	private WebDriver driver;
	private RegistrationPage registrationPage;
	
	@Given("^User is on registration Page$")
	public void user_is_on_registration_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:9987/registration");
		
		registrationPage=PageFactory.initElements(driver,RegistrationPage.class);
	}

	@When("^User fills all of his details and click on submit$")
	public void user_fills_all_of_his_details_and_click_on_submit() throws Throwable {
	registrationPage.setFirstName("Harleen");
	registrationPage.setLastName("Aggarwal");
	registrationPage.setDepartment("IT");
	registrationPage.setEmailId("harleen@gmail.com");
	registrationPage.setDesignation("Sr. Software Engineer");
	registrationPage.setBankName("HDFC");
	registrationPage.setEpf("2000");
	registrationPage.setCompanyPf("2000");
	registrationPage.clickSubmit();
	}

	@Then("^User will redirect to the registration success page$")
	public void user_will_redirect_to_the_registration_success_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration Success";
		Assert.assertEquals(expectedTitle,actualTitle);
		driver.close();
	}

}
