package com.cg.payroll.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPageStepDefinition {

	
	@Given("^User is on the Login Page$")
	public void user_is_on_the_Login_Page() throws Throwable {
	
	}

	@When("^User Fills all of credentials and clicks on submit Button$")
	public void user_Fills_all_of_credentials_and_clicks_on_submit_Button() throws Throwable {
	
	}

	@Then("^User should redirect to login Success Page$")
	public void user_should_redirect_to_login_Success_Page() throws Throwable {
	
	}
}
