package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.IndexPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class IndexPageStepDefinition {

	
	private WebDriver driver;
	private IndexPage indexPage;
	
	@Given("^User is on the Index Page$")
	public void user_is_on_the_Index_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:9987/");
		
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^User clicks on the SignUp button$")
	public void user_clicks_on_the_SignUp_button() throws Throwable {
		indexPage.clickSignUp();

	}

	@Then("^user should redirect to the Registration Page$")
	public void user_should_redirect_to_the_Registration_Page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User clicks on the SignIn button$")
	public void user_clicks_on_the_SignIn_button() throws Throwable {
	
	}

	@Then("^User should redirect to login Page$")
	public void user_should_redirect_to_login_Page() throws Throwable {

	}

}
