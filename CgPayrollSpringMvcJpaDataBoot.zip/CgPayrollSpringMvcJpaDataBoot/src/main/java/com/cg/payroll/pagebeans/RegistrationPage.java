package com.cg.payroll.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {

	@FindBy(how=How.ID,id="firstName")
	private WebElement firstName;
	
	@FindBy(how=How.ID,id="lastName")
	private WebElement lastName;
	
	@FindBy(how=How.ID,id="department")
	private WebElement department;
	
	@FindBy(how=How.ID,id="emailId")
	private WebElement emailId;
	
	@FindBy(how=How.ID,id="designation")
	private WebElement designation;
	
	@FindBy(how=How.ID,id="bankDetail.bankName")
	private WebElement bankName;
	
	@FindBy(how=How.ID,id="salary.epf")
	private WebElement epf;
	
	@FindBy(how=How.ID,id="salary.companyPf")
	private WebElement companyPf;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div/table/tbody/tr[9]/td/input")
	private WebElement button;
	
	public RegistrationPage() {
		super();
	}

	public void clickSubmit() {
	button.click();
	}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getDepartment() {
		return department.getAttribute("value");
	}

	public void setDepartment(String department) {
		this.department.sendKeys(department);
	}

	public String getEmailId() {
		return emailId.getAttribute("value");
	}

	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}

	public String getDesignation() {
		return designation.getAttribute("value");
	}

	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}

	public String getBankName() {
		return bankName.getAttribute("value");
	}

	public void setBankName(String bankName) {
		this.bankName.sendKeys(bankName);
	}

	public String getEpf() {
		return epf.getAttribute("value");
	}

	public void setEpf(String epf) {
		this.epf.clear();
		this.epf.sendKeys(epf);
	}

	public String getCompanyPf() {
		return companyPf.getAttribute("value");
	}

	public void setCompanyPf(String companyPf) {
		this.companyPf.clear();
		this.companyPf.sendKeys(companyPf);
	}


}
