package com.cg.flipkart.beans;

import java.time.LocalDate;
import java.util.Date;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Type;

@Entity
public class Order {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="orderIdGenerator")
	@SequenceGenerator(name="orderIdGenerator", sequenceName="orderId_seq", initialValue=2000)
	private int orderId;
	
	@Column
	@Type(type="date")
	private Date purchaseDate;
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="order", orphanRemoval=true)
	@MapKey
	private Map<Integer, Product> products;
	
	
	@ManyToOne
	private Customer customer;
	
	@OneToOne
	private Bill bill;

	public Order() {
		super();
	}

	public Order(Date purchaseDate, Customer customer, Bill bill) {
		super();
		this.purchaseDate = purchaseDate;
		this.customer = customer;
		this.bill = bill;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Bill getBill() {
		return bill;
	}

	public void setBill(Bill bill) {
		this.bill = bill;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", purchaseDate=" + purchaseDate + ", customer=" + customer + ", bill="
				+ bill + "]";
	}
	
}
