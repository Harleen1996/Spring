package com.cg.flipkart.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Bill {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="billIdGenerator")
	@SequenceGenerator(name="billIdGenerator", sequenceName="billId_seq", initialValue=800001)
	private int billId;
	private float totalBill;
	
	@OneToOne
	private Order order;

	public Bill() {
		super();
	}

	public Bill(float totalBill, Order order) {
		super();
		this.totalBill = totalBill;
		this.order = order;
	}

	public int getBillId() {
		return billId;
	}

	public void setBillId(int billId) {
		this.billId = billId;
	}

	public float getTotalBill() {
		return totalBill;
	}

	public void setTotalBill(float totalBill) {
		this.totalBill = totalBill;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", totalBill=" + totalBill + ", order=" + order + "]";
	} 
	
}
