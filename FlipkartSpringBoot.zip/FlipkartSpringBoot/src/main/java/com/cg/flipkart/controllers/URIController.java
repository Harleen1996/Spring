package com.cg.flipkart.controllers;

public class URIController {

}
