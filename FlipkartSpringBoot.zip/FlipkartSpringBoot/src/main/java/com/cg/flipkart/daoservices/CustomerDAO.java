package com.cg.flipkart.daoservices;

public class CustomerDAO {

}
